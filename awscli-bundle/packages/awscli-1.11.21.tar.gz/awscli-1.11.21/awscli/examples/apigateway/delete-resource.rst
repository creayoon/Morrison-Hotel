**To delete a resource in an API within the specified region**

Command::

  aws apigateway delete-resource --rest-api-id 1234123412 --resource-id a1b2c3 --region us-west-2

